"""
ebas/io/xml
$Id: __init__.py 736 2014-09-02 11:34:17Z toh $

EBAS I/O XML module
"""

from .xml import EbasXML