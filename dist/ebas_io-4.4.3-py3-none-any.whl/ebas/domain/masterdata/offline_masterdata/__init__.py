"""
Module offline_masterdata
$Id: __init__.py 2466 2020-07-10 13:20:48Z pe $
"""

from .offline_masterdata import *