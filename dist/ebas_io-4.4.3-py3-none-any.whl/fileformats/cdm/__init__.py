# CDM read
# rad EBAS NetCDF files from file or vie OPeNDAP

from .cdm import EbasCDMReader,\
    SOURCE_NETCDF, SOURCE_OPENDAP, \
    OPENDAP_BACKEND_NETCDF, OPENDAP_BACKEND_PYDAP
