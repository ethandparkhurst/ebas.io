"""
Module nilutility: small helpers and utilities
"""
__version__ = '1.18.00-next-devel'
