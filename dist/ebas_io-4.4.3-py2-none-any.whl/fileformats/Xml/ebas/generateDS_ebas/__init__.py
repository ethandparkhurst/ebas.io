"""
Module generateDS_ebas: With generateDS.py generated python data structures (for example, class definitions)
                        from ebas.xsd XML Schema document.
                        generatedssuper.py is imported by generateDS_ebas and contains ebas specific implementations.
"""

# import ebas
# import gml