"""
$Id: __init__.py 1528 2017-02-15 18:45:40Z pe $

EBAS I/O basefile module
"""
